#include <string>
#include <vector>
#include <iostream>
#include <stdio.h>

using namespace std;

class CharacterTree
{
	private:
		vector<string> array;

		int leftchild( int );
		int rightchild( int );
		int parent( int child );

	public:

		CharacterTree();
		void insert( string s, int index );
		string retrieve( int index);
		void question( void);
		void quest1( int index );
				void quest2( int index );
				void quest3( int index );
				void quest4( int index );
};

CharacterTree::CharacterTree( void )
{
	//data = NULL;
}


int CharacterTree::leftchild( int parent)
{
	return (2*parent); //returns index of left child
}

int CharacterTree::rightchild( int parent)
{
	return (2*parent+1); //returns index of left child
}

int CharacterTree::parent( int child)
{
	return child/2; //returns index of parent
}

void CharacterTree::insert( string s, int index)
{
	if(array.size()<(index+1))
	{
	array.resize(index+1);
	//cout<<"changing size"<<endl;
	}
		array.at(index)=s;
	//cout<<array[index]<<endl;
	//cout<<array.size()<<endl;


}

string CharacterTree::retrieve(int index)
{
	return array[index];

}

void CharacterTree::question(void)
{

	cout<<"Are you thinking of a character? Y/N"<<endl;
	string ext ;
	getline(cin, ext);
	if(ext == "Y"|ext=="y")
	{
		//cin.ignore();
		insert("Pony Boy", 1);
		cout<<"Is your character: "<<retrieve(1)<<"?  Y/N"<<endl;
		string ans;
		getline(cin, ans);
		if(ans == "Y"|ans=="y")
		{cout<<"Hooray!"<<endl;
		}
		else
		//if(ans == 'N'|'n')
		{
			quest1(1);
		}
	}
	else
	{
		
	}
}

void CharacterTree::quest4(int index)
{
cout<<"Are you thinking of a character? Y/N"<<endl;
	string ext ;
	
	getline(cin, ext);
	if(ext == "Y"|ext=="y")
	{
		
		quest2(index);

	}
	else
	{
	}


}

void CharacterTree::quest3(int index)
{
	
		//cin.ignore();
		
		cout<<"Is your character: "<<retrieve(index)<<"?  Y/N"<<endl;
		string ans;
		getline(cin, ans);
		if(ans == "Y"|ans=="y")
		{cout<<"Hooray!"<<endl;
			quest4(1);
		}
		else
		//if(ans == 'N'|'n')
		{
			quest1(index);
		}
	
}

void CharacterTree::quest1(int index)
{
	cout<<"What is the name of your character?"<<endl;
	//cin.ignore();
	string actchar;
	getline(cin, actchar);
	cout<<"What question would distinguish "<<actchar<<" from "<<array[index]<<"? "<<endl;
	string question;
	getline(cin, question);
	
	insert(array[index],leftchild(index));
	insert(question, index);
	insert(actchar,rightchild(index));

	//cout<<endl<<array[index]<<endl;
	//cout<<retrieve(leftchild(index))<<endl;
	//cout<<retrieve(rightchild(index))<<endl;


	quest2(index);
	


}

void CharacterTree::quest2(int index)
{
	if(rightchild(index)>=array.size())
		{
			//cout<<"looping back to guess character"<<endl;
			quest3(index);

		}
	else
	{
		//cin.ignore();
		cout<<endl<<retrieve(index)<<"  Y/N"<<endl;
		
		string ans;
		getline(cin, ans);
		
		if(ans == "Y"|ans=="y")
		{
			cout<<"You said yes. "<<endl;
			cout<<"index "<<index<<endl;
	
			index = rightchild(index);
			cout<<"index "<<index<<endl;
			

		}
		else
		//if(ans == 'N'|'n')
		{
			cout<<"you said no "<<endl;
			index = leftchild(index);
			
			//cout<<"left child"<<leftchild(index)<<endl;
		}
	//cin.ignore();
	quest2(index);

	}
}

int main( void )
{
	CharacterTree tops = CharacterTree();
	tops.question();
	///tops.insert("lemon", 1);
	//tops.insert("potato", 3);
	//tops.insert("arugalua", 2);

	//string tip;
	//tip = tops.retrieve(3);
	//cout<<tip<<endl;





	return 0;
}
