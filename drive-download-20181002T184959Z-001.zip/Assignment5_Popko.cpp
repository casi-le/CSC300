//////////////////////////////////////////////////////////////////////////////////////////////////
//Assignment 5 CSC 300 Data Structures 11/06/2015 Dakota State University
//Written by Casi Popko
//Binary search tree using an array. Array will guess fictional characters based on
//user's previous answers. It asks for characters and asks for distinguishing characteristic 
//questions. Answer yes goes to right node. Answer no goes to left node. Program can remember
//previous questions and answers.
///////////////////////////////////////////////////////////////////////////////////////////////////

#include <string>
#include <vector>
#include <iostream>
#include <stdio.h>

using namespace std;

class CharacterTree
{
	private:
		vector<string> array;

		int leftchild( int );
		int rightchild( int );
		int parent( int child );

	public:

		CharacterTree();
		void insert( string s, int index );
		string retrieve( int index);
		void question( void);
		void inputquest( int index );
		void mainquest( int index );
		void guessquest( int index );
		void startquest( int index );
		void print_tree( void );
};

CharacterTree::CharacterTree( void )
{

	array = vector<string>(1); //set a vector entitled array of 1 member
	
}

//print the array's index and values
void CharacterTree::print_tree( void )
{
	int i;
	for(i=0; i<array.size(); i++)
		cout<<"Array index: "<<i<<"Value:  "<<array[i]<<endl;

}

int CharacterTree::leftchild( int parent)
{
	return (2*parent+1); //returns index of left child
}

int CharacterTree::rightchild( int parent)
{
	return (2*parent+2); //returns index of left child
}

int CharacterTree::parent( int child)
{
	return child/2; //returns index of parent
}

//inserts a string s at index
void CharacterTree::insert( string s, int index)
{
	if(array.size()<(2*index+3))//check to see if size is large enough
	{
	array.resize(2*index+3, "timmy"); //set size larger to a default value

	}
		array.at(index)=s;


}

//returns the value at index
string CharacterTree::retrieve(int index)
{
	return array[index];

}

//sets our index to start and starts the binary search tree
void CharacterTree::question(void)
{
	int index = 0;
	insert("Pony Boy", 0);//default value--could put any character here
	startquest(index);
		

}

void CharacterTree::startquest(int index)
{
cout<<"Are you thinking of a character? Y/N"<<endl;
	string ext ;
	//print_tree();
	
	getline(cin, ext);
	if(ext == "Y"|ext=="y")
	{
		
		mainquest(index);

	}
	else//will exit the program if the user inputs anything other than Y/y
	{
	}


}

void CharacterTree::guessquest(int index)
{
		//reached a leaf node/character node. Going to guess the character		
		cout<<"Is your character: "<<retrieve(index)<<"?  Y/N"<<endl;
		string ans;
		getline(cin, ans);
		if(ans == "Y"|ans=="y") //we were correct. starting over.
		{cout<<"Hooray!"<<endl;
			startquest(0);
		}
		else if(ans == "N"|ans=="n") //we weren't correct. need to input a new distinguishing characteristic and character
		{
			inputquest(index);
		}
		else
		{	
			cout<<"I need a Y or N answer"<<endl;
			guessquest(index);
		}
	
}

void CharacterTree::inputquest(int index)
{	
	//our array doesn't have the char they're thinking of. need to input the distinguishing characteristic/character
	cout<<"What is the name of your character?"<<endl;
	string actchar;
	getline(cin, actchar);
	cout<<"What question would distinguish "<<actchar<<" from "<<array[index]<<"? "<<endl;
	string question;
	getline(cin, question);
	
	string answer;
	cout<<"If your character were "<<actchar<<", what would the answer be? Y/N"<<endl;
	getline(cin, answer);

	if(answer == "Y"|answer=="y")
	{
		insert(array[index],leftchild(index));//store the answer previously here in the left child (no answer)
		insert(actchar,rightchild(index));//store the correct answer in the right child
		insert(question, index);//store the distinguishing characteristic in this point
	}
	else if(answer == "N"|answer=="n")
	{
		insert(array[index],rightchild(index));//store the answer previously here in the right child (yes answer)
		insert(actchar, leftchild(index));//store the correct answer in the left child (no answer)
		insert(question, index);//store the distinguishing characteristic in this point
	}
	else
	{
		cout<<"Incorrect input, restarting"<<endl;
	}

	
	startquest(0);//start
	


}

void CharacterTree::mainquest(int index)
{

	if(rightchild(index)>=array.size()|array[rightchild(index)]=="timmy")//testing if we are at a leaf node
		{
			
			guessquest(index);

		}
	else //not at leaf node. Need to ask the question at the node we're at
	{
	
		cout<<endl<<retrieve(index)<<"  Y/N"<<endl;
		
		string ans;
		getline(cin, ans);;
		if(ans == "Y"|ans=="y")//the question defining our character is yes. we need to go to the right child
		{
				
			index = rightchild(index);

		}
		else if(ans == "N"|ans=="n") //the question defining our character is no. We need to go the left child
		{
			index = leftchild(index);

		}
		else
		{
			cout<<"I need a Y or N answer"<<endl;
		}

	mainquest(index); //recursive step. we go through this until we reach a leaf node --a character

	}
}

int main( void )
{
	CharacterTree tops = CharacterTree();
	tops.question();


	return 0;
}
