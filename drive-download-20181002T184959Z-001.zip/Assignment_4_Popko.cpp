#include <iostream> 
#include <stdlib.h> //exit

using namespace std;

class Priority_Queue
{
	private:
		typedef struct _node{
			int value;
			struct _node *next;
		} node;
		
		int nNodes;

		node *head;
		node *tail;

		void sort( void );


	public:

		Priority_Queue( void );
		bool empty( void );
		int size( void );
		int front( void );
		int back( void );
		void enqueue( int );
		void dequeue( void );

};


void Priority_Queue::sort( void )
{
	node *temp;
	node *temp2;

	for(temp = head; temp->next != NULL; temp = temp->next)
	{
		
		node *min;
		min = temp;

		for(temp2 = temp->next; temp2!=NULL; temp2=temp2->next)
		{
			if(temp2->value < min->value)
			{	min = temp2;
			}
		}

		if(min!=temp)
		{
			int t;
			t = min->value;
			min->value = temp->value;
			temp->value = t;
		}


	}

}


Priority_Queue::Priority_Queue( void )
{
	head = NULL;
	tail = NULL;
	nNodes = 0;
}

bool Priority_Queue::empty( void )
{
	return (head == NULL );
}

int Priority_Queue::size( void )
{
	return nNodes;
}

int Priority_Queue::front( void )
{
	return (head->value);
}

int Priority_Queue::back( void )
{

	return tail->value;

}
////////////////////////////////////////////////////////////////////////////////////////
/* Function to add an int to the queue.
If the int is the smallest or equal to the first value, it goes to the first value spot
Otherwise, it must be sorted into position from lowest int to highest int
*/
//////////////////////////////////////////////////////////////////////////////////////////
void Priority_Queue::enqueue( int value)
{
	//if loop to establish the first value
	if( head == NULL)
	{
		head = (node*)calloc( 1, sizeof( node) );//callocing memory for the queue
		head->value = value;//applying our value to the first (and only) spot in queue
	}


	else{




	//if loop if our value is less than or equal to the first value
	//this means our value will go first in queue
	if(value<=head->value)
	{
		node *temp = (node*)malloc(sizeof( node) );//creating a temp node struct

		temp->value = value;//making our first value the value inserted
		temp->next = head;//adding on the previously established queue

		head = temp; //setting the head to temp
		temp = NULL; //freeing memory
	}


	//if loop if our value is greater than the first value
	//we will need to sort through our queue to find our value's position
	if(value>head->value)
	{

		node *temp = (node*)malloc(sizeof( node) );//creating a temp node struct

		temp->value = value;//making our first value the value inserted
		temp->next = head;//adding on the previously established queue

		head = temp; //setting the head to temp
		temp = NULL; //freeing memory
		sort();

	}


	}

	//set up tail

	if( tail == NULL)
	{
		tail = (node*)calloc( 1, sizeof( node) );//callocing memory for the queue
		tail->value = value;//applying our value to the first (and only) spot in queue
	}
	else
	{

		node *tmp = (node*)malloc(sizeof( node) );
		tmp=head;
		while (tmp!=NULL)
			{
		
				if(tmp->next==NULL)
					{
						tail->value = tmp->value;

					}
			tmp=tmp->next;
			}

	}

	nNodes++;
}


/////////////////////////////////////////////////////////////////////////
/* Function to take the first value out of the queue.
*/
////////////////////////////////////////////////////////////////////////
void Priority_Queue::dequeue( void )
{
	node *temp;

	if( head != NULL )
	{
		temp = head;
		head = head->next;

		free( temp );
		temp = NULL;

		nNodes--;
	}

}




int main (int argc, char **argv)
{

	Priority_Queue my_stack = Priority_Queue();

		my_stack.enqueue(75);
		my_stack.enqueue(95);
		my_stack.enqueue(87);

		my_stack.enqueue(8);

		my_stack.enqueue(5);
		my_stack.enqueue(82);

		my_stack.dequeue();

		my_stack.enqueue(9);
		my_stack.enqueue(5);
		my_stack.enqueue(95);
		my_stack.enqueue(2);


	while( !my_stack.empty() )
	{
		cout<< "Value: " << my_stack.front() << endl;
		my_stack.dequeue();
		cout<< "Node count: "<< my_stack.size() << endl << endl;
	}
	return 0;
}
