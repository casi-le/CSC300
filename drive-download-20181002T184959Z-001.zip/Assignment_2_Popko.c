#include <stdio.h>  //printf, fopen
#include <stdlib.h> //exit

typedef struct _node{
	int value; //data to be stored in list
	struct _node *next; //pointer to next node in list

} node;

void append( node**, int);
void prepend( node**, int);
void lprint( node*);
void destroy(node*);

int main( int argc, char **argv)
{

	node *head = NULL;

	append (&head, 1);
	append (&head, 2);
 	append (&head, 3);
	lprint( head);

	prepend( &head, 0 );
	prepend( &head, -1 );
	prepend( &head, -2 );
	lprint( head);
 
	destroy( head);

	lprint( head);
	return 0;
}

void append (node **head, int value)
{
	if ( *head == NULL )
	{
	//set head to new node
	*head = (node*)calloc(0, sizeof( node ) );
	(*head)->value = value;
	}
	else
	{
	node *temp = NULL;

	//find last valid node
	for (temp = *head; temp->next != NULL; temp = temp->next);
	
	//allocat new node, set new node value using temp as reference
	temp->next = (node*)calloc( 0, sizeof(node));
	temp->next->value = value;
	}
}

void prepend( node **head, int value )
{
	//set up new node
	node *temp = NULL;
	temp = (node*)(malloc (sizeof(node)));

	//set top value as value that needs to be prepended
	temp->value = value;

	//set up temp->next as a node, set the next node to the current linkedlist
	temp->next =(node*)calloc(0, sizeof(node));
	temp->next = *head;

	//copy values in temp over to head in main
	*head = temp;
	
}

void lprint( node *head )
{
	node * temp;
	for( temp = head; temp != NULL; temp=temp->next)
	{
	printf("%d ", temp->value);
	}
	printf("\n");
}

void destroy( node *head )
{
	node *temp;
	for(temp = head; temp!=NULL; temp=temp->next)
	{
	free(temp);
	}

}






