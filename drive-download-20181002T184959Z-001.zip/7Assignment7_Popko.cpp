/*////////////////////////////////////////////
Assignment
Written by: Casi LH Popko
Date: 
Course: Data Structures CSC 300 DSU

Purpose: 
*////////////////////////////////////////////

#include <iostream> //inputs/outputs
#include <queue>    //queues
#include <fstream>  //opens file
#include <iomanip> //setw
#include <algorithm>

using namespace std;


class Graph{

	int **adjMatrix;
	string *stationids;
	int sCount;
	int rCount;

	public:

		Graph(int,int);
		~Graph(void); //destructor
		void addRoute(int,int,int);
		void printout(void);
		bool isRoute(int,int);
		void menu(void);
		int findint(string);
		void addID(int, string );
		void pam( void );
		void floyd(void);
		int shortestPath(int , int );

};

Graph::Graph( int stations, int routes ){

	adjMatrix=new int*[stations];//dynamically create an array of pointers
	for(int i = 0; i<stations;i++)
		adjMatrix[i]=new int[stations];//dynamically allocate an array for each pointer 

	for(int i = 0; i<stations;i++)
	{
		for(int n = 0; n<stations; n++)
		{
			adjMatrix[i][n]=99;//initialize each matrix point to 99
			
		}
	}

	int a;
	string b;

	stationids = new string[stations];
	


	sCount = stations;
	rCount = routes;


}

Graph::~Graph(){
	for(int i = 0; i<sCount; i++)
	{
		delete adjMatrix[i];
	}
	delete[] adjMatrix;
	adjMatrix = NULL;

	delete[] stationids;
	stationids = NULL;
}


void Graph::addRoute(int from, int to, int weight){
	adjMatrix[from][to]=weight;//set matrix value to the weight

}

void Graph::addID(int numb, string id ){
	stationids[numb] = id;

}

void Graph::printout(void){
	int i;
	int n;
	for( i = 0; i < sCount; i ++ )//loop through first position of matrix
	{


		for( n=0; n<sCount; n++ )//loop through second position of matrix
		{

			if(adjMatrix[i][n]!=99)//only print out values that actually have a weight
			{
				cout <<"from:"<<setw(2)<< i ;
				cout<<" to:"<<setw(2)<<n;
				cout << " Weight:"<<setw(2)<<adjMatrix[i][n] << endl;
				//cout<<setw(2)<<adjMatrix[i][n]<<" ";
				
			}//end if

			if(i==n){}//there should never be a value from i->i 
			else
			{
				//cout <<"from "<< i << " : ";
				//cout<<"to : "<<n;
				//cout << " Weight "<<adjMatrix[i][n] << endl;
			}//end else

		}//end for
		//cout<<endl;

	}//end for
}

void Graph::floyd(void)
{
	int i,j,k;

	for(k = 0; k < sCount; k++)
		for(i = 0; i < sCount; i++)
			for(j = 0; j < sCount; j++){
				if(i == j) continue;
				adjMatrix[i][j]= min( adjMatrix[i][j], (adjMatrix[i][k] + adjMatrix[k][j]) );
			}

}

int Graph::shortestPath(int i, int j)
{
	return adjMatrix[i][j];
}

bool Graph::isRoute( int from, int to ){


	bool isRoute = false;//assume there is no route
	bool visited[sCount];//need to keep track of visited routes
	for(int i = 0; i<=sCount; i++){

		visited[sCount]=false;//have not visited any routes yet
	 }
	visited[from]=true;

	queue<int> vertices;//sets up the queue we use to keep track of where we're at
	vertices.push(from);//push the value we're starting at onto the queue


	while( !vertices.empty() && isRoute == false ){//once we're out of vertices we're looking at, we can assume there is no route
		int current;		
		current = vertices.front();//set current to the front of our queue
		vertices.pop();//pop off the front of our queue

		//cout <<endl<< "Checking " << current << endl;

		//this for loop will check each potential station at "current" before moving onto the next level
		for( int i = 0; i<sCount;i++)//loop through each station
		{
			//cout<<"test: "<<i<<endl;

			if( visited[i]==false)//if the value does not equal 0, there is a station there
			{
				//cout<<"to: "<<i<<endl;
				vertices.push(i);//push our station(s) onto the stack
				visited[current]=true;//mark off this station as visited
				
			}

			if(adjMatrix[current][i]!=99 && i == to)//check to see if we have found our value
			{
				cout<<adjMatrix[current][i];
				cout<<"Found it"<<endl;
				isRoute = true;
				break;
			}

			
		

		}



	}
	return isRoute;

}



void Graph::menu( void ){

		string temp1;
		int temp2;
		string temp3;
		int temp4;


	bool menuOn = true;
	int choice;
	while(menuOn == true){

		cout<<"------------Menu---------"<<endl;
		cout<<"0 - Exit\n";
		cout<<"1 - Print Menu\n";
		cout<<"2 - Check if Path Exists \n";

		cin >> choice;
	
		switch(choice)
		{

		case 0:
		menuOn = false;
		break;

		case 1:
		pam();
		break;

		case 2:

		cout<<"From what station are you leaving?\n";
		cin>>temp1;
		temp2 = findint(temp1);
		cout<<"To what station are you traveling?\n";
		cin>>temp3;
		temp4 = findint(temp3);


		if(temp2 == -1|temp4==-1){
			cout<<"One or more of your stations does not exist"<<endl;
		}
		else{
			if(isRoute(temp2,temp4)==true){
				cout<<"Yes! There is a route between ";
				cout<<temp1<<" and "<< temp3<<endl;
				cout<<"Its distance is: "<<shortestPath(temp2,temp4)<<endl;
			}
			else{
				cout<<"No! There is no route between ";
				cout<<temp1<<" and "<< temp3<<endl;
			}

			}
	
		}


	}

}

void Graph::pam(void)
{
	int i,j;
	cout << endl;
	for(i = 0; i < sCount; i++){
		for(j = 0; j < sCount; j++)
			cout << setw(3) << adjMatrix[i][j] << " ";
		cout <<  endl;
	}
	cout <<  endl;
}

int Graph::findint(string s){
	int a = 0;

	while(a<sCount)
	{


		if(stationids[a]==s){

			//cout<<"a: "<<a<<endl;
			return a;

		}
		else{
		}

		a++;	
	}
return -1;

}

int main( void ){


	int a;
	int b;
	int c;
	string d;

	ifstream myfile("data.txt");

	if(!myfile)
	{
		cout<<"error opening file"<<endl;
		return -1;
	}
	else
	{
	
		myfile>>a>>b;
		Graph myGraph = Graph(a,b);
		while(myfile>>a>>b>>c)
		{
		myGraph.addRoute(a,b,c);		
	

		}
	a = 0;

	ifstream afile("ids.txt");
	while(afile>>a>>d)
		{
			myGraph.addID(a,d);

		}

		myGraph.floyd();

		myGraph.menu();
		//myGraph.printout();

		//cout << (myGraph.isRoute(0,9) ? "Yes!" : "No!") << endl;
	}


	return 0;
}


