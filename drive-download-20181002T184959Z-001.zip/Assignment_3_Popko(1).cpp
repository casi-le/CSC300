#include <iostream> 
#include <stdlib.h> //exit

using namespace std;

class Priority_Queue
{
	private:
		typedef struct _node{
			int value;
			struct _node *next;
		} node;
		
		int nNodes;

		node *head;


	public:

		Priority_Queue( void );
		bool empty( void );
		int size( void );
		int front( void );
		int back( void );
		void enqueue( int );
		void dequeue( void );

		void push( int ); //test purposes
		void pop( void ); //test purposes

};
Priority_Queue::Priority_Queue( void )
{
	head = NULL;
	nNodes = 0;
}

bool Priority_Queue::empty( void )
{
	return (head == NULL );
}

int Priority_Queue::size( void )
{
	return nNodes;
}

int Priority_Queue::front( void )
{
	return (head->value);
}

int Priority_Queue::back( void )
{
	node *tmp = (node*)malloc(sizeof( node) );
	tmp=head;
	while (tmp!=NULL)
	{
		if(tmp->next==NULL)
		{
			return tmp->value;

		}
	tmp=tmp->next;
	}

}

void Priority_Queue::enqueue( int value)
{
	if( head == NULL)
	{
		head = (node*)calloc( 1, sizeof( node) );
		head->value = value;
	}
	else{

	if(value<=head->value)
	{
		node *temp = (node*)malloc(sizeof( node) );

		temp->value = value;
		temp->next = head;

		head = temp;
		temp = NULL;
	}

	if(value>head->value)
	{

		node *tmp1 = (node*)malloc(sizeof( node) );
		node *tmp2 = (node*)malloc(sizeof( node) );
		node *newnode = (node*)malloc(sizeof( node) );

		tmp1=head;
		tmp2=head;
		int i = 0;
		


		while(value>tmp1->value)
		{
			tmp1=tmp1->next;
			i++;
		}
		cout<<i<<endl;
		while(i>1)
		{
			tmp2 = tmp2->next;
			i--;
		}
		cout<<"======"<<tmp2->value<<endl;

		head = tmp2;
		//tmp2=tmp1->next;
		//tmp1->next=newnode;
		//newnode->next=tmp2;
		//head = tmp1;
		
		//tmp1 = NULL;
		//tmp2 = NULL;
		//newnode = NULL;


	}
	}

	nNodes++;
}

void Priority_Queue::dequeue( void )
{

}

void Priority_Queue::push( int value)
{
	if( head == NULL)
	{
		head = (node*)calloc( 1, sizeof( node) );
		head->value = value;
	}
	else
	{
		node *temp = (node*)malloc(sizeof( node) );

		temp->value = value;
		temp->next = head;

		head = temp;
		temp = NULL;
	}
	nNodes++;
}

void Priority_Queue::pop( void )
{
	if( head != NULL )
	{
		node *temp = head;
		head = head->next;

		free( temp );
		temp = NULL;
		nNodes--;
	}
}

int main (int argc, char **argv)
{

	Priority_Queue my_stack = Priority_Queue();
	int i;
/*
	for( i=7; i<10; i++ )
	my_stack.push( i );

*/

		my_stack.enqueue(11);
		my_stack.enqueue(7);
		my_stack.enqueue(5);
		my_stack.enqueue(8);


		//my_stack.enqueue(9);
		//my_stack.enqueue(5);
		//my_stack.enqueue(2);
		//my_stack.enqueue(9);

	while( !my_stack.empty() )
	{
		cout<< "Value: " << my_stack.front() << endl;
		my_stack.pop();
		cout<< "Node count: "<< my_stack.size() << endl << endl;
	}
	return 0;
}
