#include <string>
#include <vector>
#include <iostream>
#include <stdio.h>

using namespace std;

class CharacterTree
{
	private:
		vector<string> array;
		int nodecount;

		int leftchild( int );
		int rightchild( int );
		int parent( int child );

	public:

		CharacterTree();
		void insert( string s, int index );
		string retrieve( int index);
		void question( void);
		void quest1( int index );
				void quest2( int index );
				void quest3( int index );
				void quest4( int index );
		void print_tree( void );
};

CharacterTree::CharacterTree( void )
{
	nodecount = 0;
	array = vector<string>(1);
	
}

void CharacterTree::print_tree( void )
{
	int i;
	for(i=0; i<array.size(); i++)
		cout<<"Array index: "<<i<<"Value:  "<<array[i]<<endl;

}

int CharacterTree::leftchild( int parent)
{
	return (2*parent+1); //returns index of left child
}

int CharacterTree::rightchild( int parent)
{
	return (2*parent+2); //returns index of left child
}

int CharacterTree::parent( int child)
{
	return child/2; //returns index of parent
}

void CharacterTree::insert( string s, int index)
{
	if(array.size()<(2*index+3))
	{
	array.resize(2*index+3, "timmy");

	}
		array.at(index)=s;



}

string CharacterTree::retrieve(int index)
{
	return array[index];

}

void CharacterTree::question(void)
{
	int index = 0;
	insert("Pony Boy", 0);
	quest4(index);
		

}

void CharacterTree::quest4(int index)
{
cout<<"Are you thinking of a character? Y/N"<<endl;
	string ext ;
	//print_tree();
	
	getline(cin, ext);
	if(ext == "Y"|ext=="y")
	{
		
		quest2(index);

	}
	else
	{
	}


}

void CharacterTree::quest3(int index)
{
	
		
		cout<<"Is your character: "<<retrieve(index)<<"?  Y/N"<<endl;
		string ans;
		getline(cin, ans);
		if(ans == "Y"|ans=="y")
		{cout<<"Hooray!"<<endl;
			quest4(0);
		}
		else
		//if(ans == 'N'|'n')
		{
			quest1(index);
		}
	
}

void CharacterTree::quest1(int index)
{
	cout<<"What is the name of your character?"<<endl;
	string actchar;
	getline(cin, actchar);
	cout<<"What question would distinguish "<<actchar<<" from "<<array[index]<<"? "<<endl;
	string question;
	getline(cin, question);
	
	insert(array[index],leftchild(index));
	insert(question, index);
	insert(actchar,rightchild(index));



	quest2(index);
	


}

void CharacterTree::quest2(int index)
{

	if(rightchild(index)>=array.size()|array[rightchild(index)]=="timmy")
		{
			
			quest3(index);

		}
	else
	{
	
		cout<<endl<<retrieve(index)<<"  Y/N"<<endl;
		
		string ans;
		getline(cin, ans);;
		if(ans == "Y"|ans=="y")
		{
				
			index = rightchild(index);

		}
		else
		//if(ans == 'N'|'n')
		{
			index = leftchild(index);

		}

	quest2(index);

	}
}

int main( void )
{
	CharacterTree tops = CharacterTree();
	tops.question();




	return 0;
}
