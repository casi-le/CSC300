#include <iostream> //input, output
#include <stdio.h>  //printf, fopen
#include <stdlib.h> //exit
#include <time.h>

void randomize(int[],int);
void printArray(int[],int);

int main( int argc, char **argv)
{
	using namespace std;
	//Error message if there are less than 2 arguments
	if( argc < 2 )
	{
		cout << "Usage: "<<argv[0]<< endl;
		exit(0);
	
	}
	

	int n = atoi(argv[1]); //converting argv[1] from char to int
	
 
	int *a = NULL;
	a = new int[n];//set memory dynamically to size n

	randomize(a, n);
	//cout<<" "<<a[1]<<a[n]<<endl;

	printArray(a,n);

	delete[] a; //free memory


	return 0;
}

/* fill integer array with random values between 1 and 100 */
void randomize( int a[], int count )
{
	srand(time(NULL));//seed value
	for(int i = 0; i<count; i++)
	{
		a[i] = (rand()%100)+1;
		//assign random number to each element of the array
		
	}


}

/* print elements of array */
void printArray( int a[], int count )
{
	for(int i = 0; i<count; i++)
	{
	//int i = 0;
	std::cout<< "  "<< a[i] <<std::endl;
	/* print each element of a */
	}

}


