#include <string>
#include <vector>
#include <iostream>
#include <stdio.h>

using namespace std;

class CharacterTree
{
	private:
		vector<string> array;

		int leftchild( int );
		int rightchild( int );
		int parent( int child );

	public:

		CharacterTree();
		void insert( string s, int index );
		string retrieve( int index);
		void question( void);

};

CharacterTree::CharacterTree( void )
{
	//data = NULL;
}


int CharacterTree::leftchild( int parent)
{
	return 2*parent; //returns index of left child
}

int CharacterTree::rightchild( int parent)
{
	return 2*parent +1; //returns index of left child
}

int CharacterTree::parent( int child)
{
	return child/2; //returns index of parent
}

void CharacterTree::insert( string s, int index)
{
	if(array.size()<(index+1))
	{
	array.resize(index+1);
	//cout<<"changing size"<<endl;
	}
		array.at(index)=s;
	//cout<<array[index]<<endl;
	//cout<<array.size()<<endl;


}

string CharacterTree::retrieve(int index)
{
	return array[index];

}

void CharacterTree::question(void)
{
	insert("Pony Boy", 0);
	cout<<"Is your character: "<<retrieve(0)<<"?  Y/N"<<endl;
	char ans;
	ans = getchar();
	if(ans == 'Y'|'y')
	{cout<<"Hooray!"<<endl;
	}
}

int main( void )
{
	CharacterTree tops = CharacterTree();
	tops.question();
	///tops.insert("lemon", 1);
	//tops.insert("potato", 3);
	//tops.insert("arugalua", 2);

	//string tip;
	//tip = tops.retrieve(3);
	//cout<<tip<<endl;





	return 0;
}
