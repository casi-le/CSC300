/*////////////////////////////////////////////
Assignment 6 - Determining Paths
Written by: Casi LH Popko
Date: 11/17/2015
Course: Data Structures CSC 300 DSU

Purpose: The purpose of this assignment is to set up 
a breadth first search using an adjacency matrix that 
is both weight and directed
*////////////////////////////////////////////

#include <iostream> //inputs/outputs
#include <queue>    //queues
#include <fstream>  //opens file

using namespace std;


class Graph{

	int **adjMatrix;
	int sCount;
	int rCount;

	public:

		Graph(int,int);
		void addRoute(int,int,int);
		void printout(void);
		bool isRoute(int,int);

};

Graph::Graph( int stations, int routes ){

	adjMatrix=new int*[stations];//dynamically create an array of pointers
	for(int i = 0; i<stations;i++)
		adjMatrix[i]=new int[stations];//dynamically allocate an array for each pointer 

	for(int i = 0; i<stations;i++)
	{
		for(int n = 0; n<stations; n++)
		{
			adjMatrix[i][n]=0;//initialize each matrix point to 0
			
		}
	}

	sCount = stations;
	rCount = routes;


}


void Graph::addRoute(int from, int to, int weight){
	adjMatrix[from][to]=weight;//set matrix value to the weight

}

void Graph::printout(void){
	int i;
	int n;
	for( i = 0; i < sCount; i ++ )//loop through first position of matrix
	{


		for( n=0; n<sCount; n++ )//loop through second position of matrix
		{

			if(adjMatrix[i][n]!=0)//only print out values that actually have a weight
			{
				cout <<"from "<< i << " : ";
				cout<<"to : "<<n;
				cout << " Weight "<<adjMatrix[i][n] << endl;
			}

			if(i==n){}//there should never be a value from i->i 
			else
			{
				//cout <<"from "<< i << " : ";
				//cout<<"to : "<<n;
				//cout << " Weight "<<adjMatrix[i][n] << endl;
			}

		}

	}
}

bool Graph::isRoute( int from, int to ){


	bool isRoute = false;//assume there is no route
	bool visited[sCount];//need to keep track of visited routes
	for(int i = 0; i<=sCount; i++){

		visited[sCount]=false;//have not visited any routes yet
	 }


	queue<int> vertices;//sets up the queue we use to keep track of where we're at
	vertices.push(from);//push the value we're starting at onto the queue


	while( !vertices.empty() && isRoute == false ){//once we're out of vertices we're looking at, we can assume there is no route
		int current;		
		current = vertices.front();//set current to the front of our queue
		vertices.pop();//pop off the front of our queue

		cout <<endl<< "Checking " << current << endl;

		//this for loop will check each potential station at "current" before moving onto the next level
		for( int i = 0; i<sCount;i++)//loop through each station
		{
			//cout<<"test: "<<i<<endl;

			if(adjMatrix[current][i]!=0 && visited[i]==false)//if the value does not equal 0, there is a station there
			{
				cout<<"to: "<<i<<endl;
				vertices.push(i);//push our station(s) onto the stack
				visited[current]=true;//mark off this station as visited
				
				if(i == to)//check to see if we have found our value
				{
					cout<<"Found it"<<endl;
					isRoute = true;
					break;
				}

			}
		

		}



	}
	return isRoute;

}

int main( void ){


	int a;
	int b;
	int c;

	ifstream myfile("data.txt");

	if(!myfile)
	{
		cout<<"error opening file"<<endl;
		return -1;
	}
	else
	{
	
		myfile>>a>>b;
		Graph myGraph = Graph(a,b);
		while(myfile>>a>>b>>c)
		{
		myGraph.addRoute(a,b,c);		
	

		}


		myGraph.printout();

		cout << (myGraph.isRoute(0,9) ? "Yes!" : "No!") << endl;
	}

	return 0;
}


