#include <iostream> 
#include <stdlib.h> //exit

using namespace std;

class Priority_Queue
{
	private:
		typedef struct _node{
			int value;
			struct _node *next;
		} node;
		
		int nNodes;

		node *head;


	public:

		Priority_Queue( void );
		bool empty( void );
		int size( void );
		int front( void );
		int back( void );
		void enqueue( int );
		void dequeue( void );

		void 	pop( void );

};
Priority_Queue::Priority_Queue( void )
{
	head = NULL;
	nNodes = 0;
}

bool Priority_Queue::empty( void )
{
	return (head == NULL );
}

int Priority_Queue::size( void )
{
	return nNodes;
}

int Priority_Queue::front( void )
{
	return (head->value);
}

int Priority_Queue::back( void )
{
	node *tmp = (node*)malloc(sizeof( node) );
	tmp=head;
	while (tmp!=NULL)
	{
		if(tmp->next==NULL)
		{
			return tmp->value;

		}
	tmp=tmp->next;
	}

}
////////////////////////////////////////////////////////////////////////////////////////
/* Function to add an int to the queue.
If the int is the smallest or equal to the first value, it goes to the first value spot
Otherwise, it must be sorted into position from lowest int to highest int
*/
//////////////////////////////////////////////////////////////////////////////////////////
void Priority_Queue::enqueue( int value)
{
	//if loop to establish the first value
	if( head == NULL)
	{
		head = (node*)calloc( 1, sizeof( node) );//callocing memory for the queue
		head->value = value;//applying our value to the first (and only) spot in queue
	}


	else{


	//if loop if our value is less than or equal to the first value
	//this means our value will go first in queue
	if(value<=head->value)
	{
		node *temp = (node*)malloc(sizeof( node) );//creating a temp node struct

		temp->value = value;//making our first value the value inserted
		temp->next = head;//adding on the previously established queue

		head = temp; //setting the head to temp
		temp = NULL; //freeing memory
	}


	//if loop if our value is greater than the first value
	//we will need to sort through our queue to find our value's position
	if(value>head->value)
	{

		//setting up a few temporary nodes/variables
		node *tmp1 = (node*)malloc(sizeof( node) );
		node *tmp2 = (node*)malloc(sizeof( node) );
		node *newnode = (node*)malloc(sizeof( node) );

		tmp1=head;

			//while loop to determine at which place we should insert our int

			while( (tmp1->next != NULL) && (value>tmp1->next->value) )
			{			

					tmp1=tmp1->next;
					cout<<tmp1->value<<endl;
					cout<<"======================"<<endl;
	


			}


		newnode->value = value;

		tmp2=tmp1->next;
		tmp1->next=newnode;
		newnode->next = tmp2;

		
		
		//freeing memory
		tmp1 = NULL;
		tmp2 = NULL;
		newnode = NULL;


	}
	}

	nNodes++;
}


/////////////////////////////////////////////////////////////////////////
/* Function to take the first value out of the queue.
Since this is a priority queue, it will take out the max int value
*/
////////////////////////////////////////////////////////////////////////
void Priority_Queue::dequeue( void )
{
	//check that our queue exists
	if( head != NULL )
	{
		//set up temporary nodes to use
		node *temp = head;
		node *prev;

		//check to make sure that we are not on the last value
		if(temp->next!= NULL)
		{

			//loop to get to the last value
			while(temp->next != NULL)
			{
				prev = temp;
				temp=prev->next;//update loop
			}
			prev->next = NULL;
			temp = NULL;// deleting temp
		}
		else
		{
			head = NULL;//set head to NULL if there is only one value to dequeue
		}

		nNodes--;//update node count
	}
}


/* remove node from top of stack */
void Priority_Queue::pop( void )
{
	node *temp;

	if( head != NULL )
	{
		temp = head;
		head = head->next;

		free( temp );
		temp = NULL;

		nNodes--;
	}

}

int main (int argc, char **argv)
{

	Priority_Queue my_stack = Priority_Queue();

		my_stack.enqueue(75);
		my_stack.enqueue(11);
		my_stack.enqueue(7);
		my_stack.enqueue(5);
		my_stack.dequeue();
		my_stack.enqueue(8);


		my_stack.enqueue(9);
		my_stack.enqueue(5);

		my_stack.enqueue(95);

		my_stack.enqueue(2);

	while( !my_stack.empty() )
	{
		cout<< "Value: " << my_stack.front() << endl;
		my_stack.pop();
		cout<< "Node count: "<< my_stack.size() << endl << endl;
	}
	return 0;
}
